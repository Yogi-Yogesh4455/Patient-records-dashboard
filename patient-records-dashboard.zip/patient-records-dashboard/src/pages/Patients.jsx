import React, { useEffect, useState } from 'react'
import PatientCard from '../shared/PatientCard'
import PatientModal from '../shared/PatientModal'
import AddPatientForm from '../shared/AddPatientForm'

export default function Patients(){
  const [patients, setPatients] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState(null)

  useEffect(() => {
    setLoading(true)
    fetch('/patients.json')
      .then(res => {
        if (!res.ok) throw new Error('Failed to load patients.json')
        return res.json()
      })
      .then(data => {
        setPatients(data)
        setError(null)
      })
      .catch(err => setError(err.message))
      .finally(() => setLoading(false))
  }, [])

  function handleAdd(newPatient){
    setPatients(prev => [newPatient, ...prev])
  }

  const filtered = patients.filter(p =>
    p.name.toLowerCase().includes(query.toLowerCase())
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h2 className="text-2xl font-semibold">Patients</h2>
        <div className="flex items-center gap-3">
          <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search by name" className="px-3 py-2 border rounded" />
        </div>
      </div>

      <div className="grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-4">
        <div className="md:col-span-3">
          <AddPatientForm onAdd={handleAdd} />
        </div>
      </div>

      {loading && <div className="bg-white p-4 rounded shadow">Loading patients...</div>}
      {error && <div className="bg-red-50 p-4 rounded shadow text-red-700">Error: {error}</div>}

      <div className="grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-4">
        {filtered.map(patient => (
          <PatientCard key={patient.id} patient={patient} onView={() => setSelected(patient)} />
        ))}
        {!loading && filtered.length === 0 && <div className="text-gray-500 p-4">No patients found.</div>}
      </div>

      {selected && <PatientModal patient={selected} onClose={()=>setSelected(null)} />}
    </div>
  )
}
