import React from 'react'

export default function About(){
  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-xl font-semibold">About</h2>
      <p className="text-gray-600 mt-2">This demo app showcases a patient records dashboard built with React, Vite and TailwindCSS.</p>
    </div>
  )
}
