import React from 'react'
import { Link } from 'react-router-dom'

export default function Home(){
  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded shadow">
        <h2 className="text-2xl font-semibold">Welcome to Jarurat Care</h2>
        <p className="text-gray-600 mt-2">Manage patient records quickly and securely.</p>
        <Link to="/patients" className="inline-block mt-4 px-4 py-2 bg-indigo-600 text-white rounded">View Patients</Link>
      </div>
    </div>
  )
}
