import React from 'react'

export default function PatientCard({ patient, onView }){
  return (
    <div className="bg-white p-4 rounded shadow flex flex-col justify-between">
      <div>
        <div className="text-lg font-semibold">{patient.name}</div>
        <div className="text-sm text-gray-500">Age: {patient.age}</div>
        <div className="text-sm text-gray-500">Contact: {patient.contact}</div>
      </div>
      <div className="mt-4 flex gap-2">
        <button onClick={onView} className="px-3 py-2 bg-indigo-600 text-white rounded">View Details</button>
      </div>
    </div>
  )
}
