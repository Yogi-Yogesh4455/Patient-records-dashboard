import React from 'react'

export default function PatientModal({ patient, onClose }){
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded max-w-lg w-full p-6">
        <div className="flex justify-between items-center">
          <h3 className="text-xl font-semibold">{patient.name}</h3>
          <button onClick={onClose} className="text-gray-500">Close</button>
        </div>
        <div className="mt-4 space-y-2">
          <div><strong>Age:</strong> {patient.age}</div>
          <div><strong>Contact:</strong> {patient.contact}</div>
          <div><strong>Address:</strong> {patient.address}</div>
          <div><strong>Notes:</strong> {patient.notes}</div>
        </div>
      </div>
    </div>
  )
}
