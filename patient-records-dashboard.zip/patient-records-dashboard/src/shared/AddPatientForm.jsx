import React, { useState } from 'react'

export default function AddPatientForm({ onAdd }){
  const [name, setName] = useState('')
  const [age, setAge] = useState('')
  const [contact, setContact] = useState('')
  const [submitting, setSubmitting] = useState(false)

  function handleSubmit(e){
    e.preventDefault()
    if (!name) return
    setSubmitting(true)
    const newPatient = {
      id: Date.now(),
      name,
      age: age || 'N/A',
      contact: contact || 'N/A',
      address: '',
      notes: ''
    }
    // local-only update
    setTimeout(() => {
      onAdd(newPatient)
      setName(''); setAge(''); setContact('')
      setSubmitting(false)
    }, 500)
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white p-4 rounded shadow space-y-3">
      <h3 className="font-semibold">Add New Patient</h3>
      <div className="grid sm:grid-cols-3 gap-2">
        <input value={name} onChange={e=>setName(e.target.value)} placeholder="Name" className="px-2 py-2 border rounded col-span-2" />
        <input value={age} onChange={e=>setAge(e.target.value)} placeholder="Age" className="px-2 py-2 border rounded" />
        <input value={contact} onChange={e=>setContact(e.target.value)} placeholder="Contact" className="px-2 py-2 border rounded col-span-3" />
      </div>
      <div>
        <button type="submit" disabled={submitting} className="px-4 py-2 bg-green-600 text-white rounded">
          {submitting ? 'Adding...' : 'Add Patient'}
        </button>
      </div>
    </form>
  )
}
