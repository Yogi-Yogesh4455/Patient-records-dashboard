import React from 'react'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Patients from './pages/Patients'
import About from './pages/About'

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen flex flex-col">
        <header className="bg-white shadow">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center text-white font-bold">JC</div>
              <div>
                <h1 className="text-lg font-semibold">Jarurat Care</h1>
                <p className="text-sm text-gray-500">Patient Records Dashboard</p>
              </div>
            </div>
            <nav className="space-x-4">
              <Link to="/" className="text-gray-600 hover:text-indigo-600">Home</Link>
              <Link to="/patients" className="text-gray-600 hover:text-indigo-600">Patients</Link>
              <Link to="/about" className="text-gray-600 hover:text-indigo-600">About</Link>
            </nav>
          </div>
        </header>

        <main className="flex-1 container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/patients" element={<Patients />} />
            <Route path="/about" element={<About />} />
          </Routes>
        </main>

        <footer className="bg-white border-t">
          <div className="container mx-auto px-4 py-4 text-sm text-gray-500">© Jarurat Care</div>
        </footer>
      </div>
    </BrowserRouter>
  )
}
